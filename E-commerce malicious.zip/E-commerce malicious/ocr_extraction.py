import cv2
import pytesseract
import requests
from io import BytesIO
from PIL import Image

# Set path to tesseract executable (modify if needed)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

def extract_text_from_image(image_url):
    # Get image from URL
    response = requests.get(image_url)
    img = Image.open(BytesIO(response.content))

    # Convert image to grayscale for better OCR accuracy
    gray_img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2GRAY)

    # Perform OCR to extract text
    extracted_text = pytesseract.image_to_string(gray_img)
    return extracted_text

# Example usage: extract text from a webpage image
image_url = 'https://example.com/fake-deal-banner.jpg'
text = extract_text_from_image(image_url)
print(f"Extracted text: {text}")
