import requests
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
import pickle
import nltk

# Ensure NLTK resources are available
nltk.download('punkt')

# Sample data: list of website content and corresponding labels (1 = Malicious, 0 = Safe)
websites_data = [
    ("Get huge discounts now, limited time offer!", 1),
    ("Secure shopping, check our customer reviews", 0),
    # Add more examples
]

# Split data into features and labels
texts, labels = zip(*websites_data)

# Convert texts to numerical features
vectorizer = TfidfVectorizer(stop_words='english')
X = vectorizer.fit_transform(texts)
y = labels

# Train a Random Forest model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Evaluate and save the model
accuracy = model.score(X_test, y_test)
print(f"Model accuracy: {accuracy * 100:.2f}%")

# Save the model and vectorizer
with open('malicious_model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('vectorizer.pkl', 'wb') as f:
    pickle.dump(vectorizer, f)
