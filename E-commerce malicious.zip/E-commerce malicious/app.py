from flask import Flask, request, jsonify
import pickle
import numpy as np

# Load the trained model and vectorizer
with open('malicious_model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

app = Flask(__name__)

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    page_text = data['text']
    
    # Transform the page content using the vectorizer
    vectorized_text = vectorizer.transform([page_text])
    
    # Predict if the page is malicious or safe
    prediction = model.predict(vectorized_text)
    is_malicious = prediction[0] == 1
    
    return jsonify({'is_malicious': is_malicious})

if __name__ == '__main__':
    app.run(debug=True)
