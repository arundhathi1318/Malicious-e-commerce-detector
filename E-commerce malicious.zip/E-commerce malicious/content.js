// content.js - Browser extension script

// Trigger the malicious website check when the page is loaded
window.onload = function() {
    const pageContent = document.body.innerText;

    // Fetch model and vectorizer from the server
    fetch('http://localhost:5000/analyze', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: pageContent }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.is_malicious) {
            alert('Warning: This website appears to be malicious!');
            highlightSuspiciousElements();
        }
    });
};

// Highlight suspicious elements on the page
function highlightSuspiciousElements() {
    const elements = document.querySelectorAll('h1, h2, h3, p, a');
    elements.forEach(element => {
        if (element.innerText.toLowerCase().includes('discount') || element.innerText.toLowerCase().includes('offer')) {
            element.style.border = '2px solid red';
            element.style.backgroundColor = 'yellow';
        }
    });
}
